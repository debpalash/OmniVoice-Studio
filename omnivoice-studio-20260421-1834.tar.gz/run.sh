#!/usr/bin/env bash
# Launch OmniVoice Studio. Starts the FastAPI backend and opens the web UI.
# Press Ctrl+C to shut it all down.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Make sure common shell-installed tools are on PATH (non-login shells may miss them).
export PATH="$HOME/.local/bin:$HOME/.bun/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

if [[ ! -d .venv ]]; then
  echo "✗ No .venv/ — run ./install.sh first." >&2
  exit 1
fi

# Start backend in the background, tee its log so the user sees progress.
LOG_DIR="$HOME/Library/Application Support/OmniVoice"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/omnivoice-run.log"

echo "▸ Starting backend (log: $LOG_FILE)…"
uv run uvicorn main:app --app-dir backend --host 127.0.0.1 --port 8000 \
  >"$LOG_FILE" 2>&1 &
BACKEND_PID=$!

cleanup() {
  echo ""
  echo "▸ Shutting down backend (pid $BACKEND_PID)…"
  kill "$BACKEND_PID" 2>/dev/null || true
  wait "$BACKEND_PID" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

# Wait for backend to come up (up to 60s)
echo "▸ Waiting for backend…"
for i in {1..60}; do
  if curl -sf http://127.0.0.1:8000/system/info -o /dev/null; then
    break
  fi
  sleep 1
done

if ! curl -sf http://127.0.0.1:8000/system/info -o /dev/null; then
  echo "✗ Backend didn't start in 60s. See $LOG_FILE for errors." >&2
  tail -n 20 "$LOG_FILE" >&2 || true
  exit 1
fi

echo "▸ Backend up. Opening UI at http://127.0.0.1:8000/ …"

# Open the frontend in the default browser.
open "http://127.0.0.1:8000/" 2>/dev/null || true

echo ""
echo "OmniVoice Studio is running."
echo "Press Ctrl+C to shut down."

# Block until user hits Ctrl+C or backend exits.
wait "$BACKEND_PID"
